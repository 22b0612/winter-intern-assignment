# Chat App Project

## Setup Instructions

### Backend
1. Navigate to the `backend` folder.
2. Install dependencies: `npm install`
3. Start the server: `npm run dev`

### Frontend
1. Navigate to the `frontend` folder.
2. Install dependencies: `npm install`
3. Start the frontend: `npm start`

Access the application at `http://localhost:3000`.