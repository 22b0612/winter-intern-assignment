const express = require('express');
const Message = require('../models/Message');

const router = express.Router();

// Send message route
router.post('/send', async (req, res) => {
  const { sender, receiver, message } = req.body;
  const newMessage = new Message({ sender, receiver, message });
  await newMessage.save();
  res.status(201).json(newMessage);
});

// Get chat history
router.get('/history/:sender/:receiver', async (req, res) => {
  const { sender, receiver } = req.params;
  const messages = await Message.find({ $or: [
    { sender, receiver },
    { sender: receiver, receiver: sender }
  ] }).sort({ timestamp: 1 });
  res.json(messages);
});

module.exports = router;